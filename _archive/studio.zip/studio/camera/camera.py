from __future__ import annotations

import numpy as np


class V5Camera:
    """Caméra unique V5, pilotée directement par ProjectConfig."""

    def __init__(self, path_coords, camera_config):
        self.coords = np.asarray(path_coords, dtype=float)
        if len(self.coords) < 2:
            raise ValueError("La trajectoire doit contenir au moins deux points.")

        self.config = camera_config
        self.center = self.coords.mean(axis=0)
        self.min_xy = self.coords[:, :2].min(axis=0)
        self.max_xy = self.coords[:, :2].max(axis=0)
        extent = self.max_xy - self.min_xy
        self.route_size = float(max(extent[0], extent[1], 1.0))
        self.min_z = float(self.coords[:, 2].min())
        self.max_z = float(self.coords[:, 2].max())
        self.relief = max(1.0, self.max_z - self.min_z)

        self.previous_position = None
        self.previous_focal = None
        self.previous_side = 1.0
        self.fixed_side_sign = 1.0
        self.previous_direction = None
        self.max_heading_change = np.radians(12.0)
        self.direction_smoothing = 0.035

    @staticmethod
    def clamp(value, minimum, maximum):
        return max(minimum, min(maximum, float(value)))

    @staticmethod
    def normalize(vector):
        vector = np.asarray(vector, dtype=float)
        norm = np.linalg.norm(vector)
        if norm < 1e-9:
            return np.array([0.0, 1.0, 0.0], dtype=float)
        return vector / norm

    def index_at_progress(self, progress):
        progress = self.clamp(progress, 0.0, 1.0)
        return int(round(progress * (len(self.coords) - 1)))

    def direction_between(self, first, second):
        first = max(0, min(len(self.coords) - 1, int(first)))
        second = max(0, min(len(self.coords) - 1, int(second)))
        direction = self.coords[second] - self.coords[first]
        direction[2] = 0.0
        return self.normalize(direction)

    def local_direction(self, index):
        window = max(12, int(self.config.look_ahead // 6))
        target = self.direction_between(index - window, index + window)

        if self.previous_direction is None:
            self.previous_direction = target.copy()
            return target

        previous = self.normalize(self.previous_direction)

        dot_value = self.clamp(
            np.dot(previous[:2], target[:2]),
            -1.0,
            1.0,
        )

        angle = float(np.arccos(dot_value))
        cross = previous[0] * target[1] - previous[1] * target[0]
        signed_angle = angle if cross >= 0.0 else -angle
        signed_angle = self.clamp(
            signed_angle,
            -self.max_heading_change,
            self.max_heading_change,
        )

        rotation = signed_angle * self.direction_smoothing
        cosine = np.cos(rotation)
        sine = np.sin(rotation)

        rotated = np.array(
            [
                previous[0] * cosine - previous[1] * sine,
                previous[0] * sine + previous[1] * cosine,
                0.0,
            ],
            dtype=float,
        )

        self.previous_direction = self.normalize(rotated)
        return self.previous_direction

    def local_relief(self, index):
        window = max(20, int(self.config.look_ahead // 2))
        start = max(0, index - window)
        end = min(len(self.coords), index + window + 1)
        values = self.coords[start:end, 2]
        return float(values.max() - values.min())

    def local_max_altitude(self, index):
        window = max(20, int(self.config.look_ahead // 2))
        start = max(0, index - window)
        end = min(len(self.coords), index + window + 1)
        return float(self.coords[start:end, 2].max())

    def turn_side(self, index):
        window = max(8, int(self.config.look_ahead // 10))
        before = self.direction_between(index - window, index)
        after = self.direction_between(index, index + window)
        cross = before[0] * after[1] - before[1] * after[0]
        target = self.previous_side if abs(cross) < 0.03 else (-1.0 if cross > 0 else 1.0)
        self.previous_side = self.previous_side * 0.94 + target * 0.06
        return self.previous_side

    def smooth(self, previous, current):
        alpha = self.clamp(self.config.smoothing, 0.01, 1.0)
        current = np.asarray(current, dtype=float)
        if previous is None:
            return current.copy()
        return np.asarray(previous, dtype=float) * (1.0 - alpha) + current * alpha

    def endpoint_wide_factor(self, progress):
        window = 0.06
        if progress < window:
            x = 1.0 - progress / window
        elif progress > 1.0 - window:
            x = (progress - (1.0 - window)) / window
        else:
            return 0.0
        x = self.clamp(x, 0.0, 1.0)
        return x * x * (3.0 - 2.0 * x)

    def camera_at_progress(self, progress):
        progress = self.clamp(progress, 0.0, 1.0)
        index = self.index_at_progress(progress)
        active = self.coords[index]

        look_steps = max(2, int(self.config.look_ahead))
        middle_index = min(
            len(self.coords) - 1,
            index + max(6, int(look_steps * 0.22)),
        )
        look_index = min(
            len(self.coords) - 1,
            index + max(10, int(look_steps * 0.42)),
        )
        middle = self.coords[middle_index]
        look = self.coords[look_index]

        direction = self.local_direction(index)
        side = np.array([-direction[1], direction[0], 0.0], dtype=float)

        local_relief = self.local_relief(index)
        relief_factor = self.clamp(local_relief / self.relief, 0.0, 1.0)

        distance = self.clamp(
            self.route_size * self.config.distance.scale * (0.72 + 0.10 * relief_factor),
            self.config.distance.minimum,
            self.config.distance.maximum,
        )
        height = self.clamp(
            self.route_size * self.config.height.scale * (0.62 + 0.12 * relief_factor),
            self.config.height.minimum,
            self.config.height.maximum,
        )
        lateral = self.clamp(
            distance * self.config.lateral.scale * 0.55,
            self.config.lateral.minimum,
            self.config.lateral.maximum,
        )

        moving_center = active * 0.72 + middle * 0.20 + look * 0.08
        position = moving_center - direction * distance
        position += side * lateral * self.fixed_side_sign

        clearance = max(120.0, height * 0.14)
        position[2] = max(active[2] + height, self.local_max_altitude(index) + clearance)

        focal = active * 0.58 + middle * 0.32 + look * 0.10
        focal[2] += max(20.0, height * 0.035)

        position = self.smooth(self.previous_position, position)
        focal = self.smooth(self.previous_focal, focal)
        self.previous_position = position.copy()
        self.previous_focal = focal.copy()

        return position, focal, index
