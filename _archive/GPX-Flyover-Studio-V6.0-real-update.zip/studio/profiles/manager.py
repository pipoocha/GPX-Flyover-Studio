from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SuggestedProfile:
    terrain: str
    style: str
    quality: str
    duration_seconds: int


class ProfileManager:
    """Transforme l'analyse GPX en réglages de projet cohérents."""

    TERRAIN_PRESETS: dict[str, dict[str, Any]] = {
        "Plaine": {
            "camera": (500.0, 1800.0, 0.20, 220.0, 800.0, 0.09, 30.0, 220.0, 0.05, 150, 0.08),
            "terrain": (0.018, 70000, 15),
        },
        "Collines": {
            "camera": (700.0, 2300.0, 0.26, 320.0, 1100.0, 0.12, 50.0, 300.0, 0.07, 180, 0.08),
            "terrain": (0.016, 85000, 15),
        },
        "Moyenne montagne": {
            "camera": (900.0, 3000.0, 0.32, 450.0, 1450.0, 0.16, 70.0, 380.0, 0.08, 210, 0.09),
            "terrain": (0.015, 100000, 14),
        },
        "Haute montagne": {
            "camera": (1100.0, 3600.0, 0.38, 600.0, 1900.0, 0.20, 90.0, 450.0, 0.09, 240, 0.10),
            "terrain": (0.014, 125000, 14),
        },
        "Himalaya": {
            "camera": (1250.0, 4200.0, 0.42, 700.0, 2300.0, 0.23, 100.0, 480.0, 0.09, 260, 0.10),
            "terrain": (0.014, 150000, 14),
        },
    }

    QUALITY_PRESETS = {
        "Rapide": (0.55, 20, "854x480"),
        "Standard": (0.80, 20, "1280x720"),
        "Haute": (1.00, 30, "1920x1080"),
        "Ultra": (1.35, 30, "2560x1440"),
    }

    @classmethod
    def suggest(cls, analysis) -> SuggestedProfile:
        return SuggestedProfile(
            terrain=analysis.terrain_profile,
            style=analysis.suggested_style,
            quality=analysis.suggested_quality,
            duration_seconds=analysis.suggested_duration_seconds,
        )

    @classmethod
    def apply_to_project(
        cls,
        project,
        *,
        terrain: str,
        style: str,
        quality: str,
        duration_seconds: int,
    ):
        preset = deepcopy(
            cls.TERRAIN_PRESETS.get(
                terrain,
                cls.TERRAIN_PRESETS["Moyenne montagne"],
            )
        )
        quality_factor, fps, resolution = cls.QUALITY_PRESETS.get(
            quality,
            cls.QUALITY_PRESETS["Standard"],
        )

        (
            dmin, dmax, dscale,
            hmin, hmax, hscale,
            lmin, lmax, lscale,
            look_ahead, smoothing,
        ) = preset["camera"]

        project.camera.distance.minimum = dmin
        project.camera.distance.maximum = dmax
        project.camera.distance.scale = dscale
        project.camera.height.minimum = hmin
        project.camera.height.maximum = hmax
        project.camera.height.scale = hscale
        project.camera.lateral.minimum = lmin
        project.camera.lateral.maximum = lmax
        project.camera.lateral.scale = lscale
        project.camera.look_ahead = look_ahead
        project.camera.smoothing = smoothing

        margin, max_cells, satellite_zoom = preset["terrain"]
        project.terrain.margin = margin
        project.terrain.max_cells = int(max_cells * quality_factor)
        project.terrain.satellite_zoom = satellite_zoom

        project.timeline.travel = int(duration_seconds)
        project.timeline.start_hold = 3.0
        project.timeline.arrival_hold = 5.0
        project.timeline.profile_animation = 6.0
        project.timeline.profile_hold = 4.0

        project.video.fps = fps
        width, height = resolution.split("x", 1)
        project.video.width = int(width)
        project.video.height = int(height)

        style_map = {
            "Tour de France": "director",
            "Hélicoptère": "director",
            "Cinéma": "director",
            "Drone": "flyover",
            "Director": "director",
        }
        project.camera.mode = style_map.get(style, "director")
        return project
