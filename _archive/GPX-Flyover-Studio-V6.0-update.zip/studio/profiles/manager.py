from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SuggestedProfile:
    terrain: str
    style: str
    quality: str
    duration_seconds: int


class ProfileManager:
    """Applique des réglages cohérents à partir de l'analyse GPX."""

    TERRAIN_PRESETS: dict[str, dict[str, Any]] = {
        "Plaine": {
            "camera": {
                "distance_min": 500.0,
                "distance_max": 1800.0,
                "distance_scale": 0.20,
                "height_min": 220.0,
                "height_max": 800.0,
                "height_scale": 0.09,
                "lateral_min": 30.0,
                "lateral_max": 220.0,
                "lateral_scale": 0.05,
                "look_ahead": 150,
                "smoothing": 0.08,
            },
            "terrain": {
                "margin": 0.018,
                "max_cells": 70000,
                "satellite_zoom": 15,
            },
        },
        "Collines": {
            "camera": {
                "distance_min": 700.0,
                "distance_max": 2300.0,
                "distance_scale": 0.26,
                "height_min": 320.0,
                "height_max": 1100.0,
                "height_scale": 0.12,
                "lateral_min": 50.0,
                "lateral_max": 300.0,
                "lateral_scale": 0.07,
                "look_ahead": 180,
                "smoothing": 0.08,
            },
            "terrain": {
                "margin": 0.016,
                "max_cells": 85000,
                "satellite_zoom": 15,
            },
        },
        "Moyenne montagne": {
            "camera": {
                "distance_min": 900.0,
                "distance_max": 3000.0,
                "distance_scale": 0.32,
                "height_min": 450.0,
                "height_max": 1450.0,
                "height_scale": 0.16,
                "lateral_min": 70.0,
                "lateral_max": 380.0,
                "lateral_scale": 0.08,
                "look_ahead": 210,
                "smoothing": 0.09,
            },
            "terrain": {
                "margin": 0.015,
                "max_cells": 100000,
                "satellite_zoom": 14,
            },
        },
        "Haute montagne": {
            "camera": {
                "distance_min": 1100.0,
                "distance_max": 3600.0,
                "distance_scale": 0.38,
                "height_min": 600.0,
                "height_max": 1900.0,
                "height_scale": 0.20,
                "lateral_min": 90.0,
                "lateral_max": 450.0,
                "lateral_scale": 0.09,
                "look_ahead": 240,
                "smoothing": 0.10,
            },
            "terrain": {
                "margin": 0.014,
                "max_cells": 125000,
                "satellite_zoom": 14,
            },
        },
        "Himalaya": {
            "camera": {
                "distance_min": 1250.0,
                "distance_max": 4200.0,
                "distance_scale": 0.42,
                "height_min": 700.0,
                "height_max": 2300.0,
                "height_scale": 0.23,
                "lateral_min": 100.0,
                "lateral_max": 480.0,
                "lateral_scale": 0.09,
                "look_ahead": 260,
                "smoothing": 0.10,
            },
            "terrain": {
                "margin": 0.014,
                "max_cells": 150000,
                "satellite_zoom": 14,
            },
        },
    }

    QUALITY_PRESETS: dict[str, dict[str, Any]] = {
        "Rapide": {
            "terrain_max_cells_factor": 0.55,
            "video_fps": 20,
            "resolution": "854x480",
        },
        "Standard": {
            "terrain_max_cells_factor": 0.80,
            "video_fps": 20,
            "resolution": "1280x720",
        },
        "Haute": {
            "terrain_max_cells_factor": 1.00,
            "video_fps": 30,
            "resolution": "1920x1080",
        },
        "Ultra": {
            "terrain_max_cells_factor": 1.35,
            "video_fps": 30,
            "resolution": "2560x1440",
        },
    }

    @classmethod
    def suggest(cls, analysis) -> SuggestedProfile:
        return SuggestedProfile(
            terrain=analysis.terrain_profile,
            style=analysis.suggested_style,
            quality=analysis.suggested_quality,
            duration_seconds=analysis.suggested_duration_seconds,
        )

    @classmethod
    def settings_for(
        cls,
        terrain: str,
        quality: str,
        duration_seconds: int,
    ) -> dict[str, Any]:
        terrain_settings = deepcopy(
            cls.TERRAIN_PRESETS.get(
                terrain,
                cls.TERRAIN_PRESETS["Moyenne montagne"],
            )
        )

        quality_settings = cls.QUALITY_PRESETS.get(
            quality,
            cls.QUALITY_PRESETS["Standard"],
        )

        terrain_settings["terrain"]["max_cells"] = int(
            terrain_settings["terrain"]["max_cells"]
            * quality_settings["terrain_max_cells_factor"]
        )

        terrain_settings["video"] = {
            "fps": quality_settings["video_fps"],
            "resolution": quality_settings["resolution"],
        }

        terrain_settings["timeline"] = {
            "travel": int(duration_seconds),
            "start_hold": 3.0,
            "arrival_hold": 5.0,
            "profile_animation": 6.0,
            "profile_hold": 4.0,
        }

        return terrain_settings

    @classmethod
    def apply_to_project(
        cls,
        project,
        *,
        terrain: str,
        style: str,
        quality: str,
        duration_seconds: int,
    ):
        settings = cls.settings_for(
            terrain=terrain,
            quality=quality,
            duration_seconds=duration_seconds,
        )

        camera = settings["camera"]
        project.camera.distance.minimum = camera["distance_min"]
        project.camera.distance.maximum = camera["distance_max"]
        project.camera.distance.scale = camera["distance_scale"]

        project.camera.height.minimum = camera["height_min"]
        project.camera.height.maximum = camera["height_max"]
        project.camera.height.scale = camera["height_scale"]

        project.camera.lateral.minimum = camera["lateral_min"]
        project.camera.lateral.maximum = camera["lateral_max"]
        project.camera.lateral.scale = camera["lateral_scale"]

        project.camera.look_ahead = camera["look_ahead"]
        project.camera.smoothing = camera["smoothing"]

        terrain_settings = settings["terrain"]
        project.terrain.margin = terrain_settings["margin"]
        project.terrain.max_cells = terrain_settings["max_cells"]
        project.terrain.satellite_zoom = terrain_settings["satellite_zoom"]

        project.timeline.travel = settings["timeline"]["travel"]
        project.timeline.start_hold = settings["timeline"]["start_hold"]
        project.timeline.arrival_hold = settings["timeline"]["arrival_hold"]
        project.timeline.profile_animation = settings["timeline"][
            "profile_animation"
        ]
        project.timeline.profile_hold = settings["timeline"]["profile_hold"]

        project.video.fps = settings["video"]["fps"]
        width, height = settings["video"]["resolution"].split("x", 1)
        project.video.width = int(width)
        project.video.height = int(height)

        # Le style est conservé comme mode lisible par l'interface.
        style_map = {
            "Tour de France": "director",
            "Hélicoptère": "director",
            "Cinéma": "director",
            "Drone": "flyover",
            "Director": "director",
        }
        project.camera.mode = style_map.get(style, "director")

        return project
