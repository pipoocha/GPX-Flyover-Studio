from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SuggestedProfile:
    terrain: str
    style: str
    quality: str
    duration_seconds: int


class ProfileManager:
    TERRAIN_PRESETS: dict[str, dict[str, Any]] = {
        "Plaine": {
            "camera": (500, 1800, 0.20, 220, 800, 0.09, 30, 220, 0.05, 150, 0.08),
            "terrain": (0.018, 70000, 15),
        },
        "Collines": {
            "camera": (700, 2300, 0.26, 320, 1100, 0.12, 50, 300, 0.07, 180, 0.08),
            "terrain": (0.016, 85000, 15),
        },
        "Moyenne montagne": {
            "camera": (900, 3000, 0.32, 450, 1450, 0.16, 70, 380, 0.08, 210, 0.09),
            "terrain": (0.015, 100000, 14),
        },
        "Haute montagne": {
            "camera": (1100, 3600, 0.38, 600, 1900, 0.20, 90, 450, 0.09, 240, 0.10),
            "terrain": (0.014, 125000, 14),
        },
        "Himalaya": {
            "camera": (1250, 4200, 0.42, 700, 2300, 0.23, 100, 480, 0.09, 260, 0.10),
            "terrain": (0.014, 150000, 14),
        },
    }

    QUALITY_PRESETS = {
        "Rapide": (0.55, 20, "854x480"),
        "Standard": (0.80, 20, "1280x720"),
        "Haute": (1.00, 30, "1920x1080"),
        "Ultra": (1.35, 30, "2560x1440"),
    }

    @classmethod
    def suggest(cls, analysis) -> SuggestedProfile:
        return SuggestedProfile(
            terrain=analysis.terrain_profile,
            style=analysis.suggested_style,
            quality=analysis.suggested_quality,
            duration_seconds=analysis.suggested_duration_seconds,
        )

    @classmethod
    def apply_to_project(
        cls,
        project,
        *,
        terrain: str,
        style: str,
        quality: str,
        duration_seconds: int,
    ):
        preset = deepcopy(
            cls.TERRAIN_PRESETS.get(
                terrain,
                cls.TERRAIN_PRESETS["Moyenne montagne"],
            )
        )
        camera = preset["camera"]
        (
            project.camera.distance.minimum,
            project.camera.distance.maximum,
            project.camera.distance.scale,
            project.camera.height.minimum,
            project.camera.height.maximum,
            project.camera.height.scale,
            project.camera.lateral.minimum,
            project.camera.lateral.maximum,
            project.camera.lateral.scale,
            project.camera.look_ahead,
            project.camera.smoothing,
        ) = camera

        margin, max_cells, satellite_zoom = preset["terrain"]
        factor, fps, resolution = cls.QUALITY_PRESETS.get(
            quality,
            cls.QUALITY_PRESETS["Standard"],
        )
        project.terrain.margin = margin
        project.terrain.max_cells = int(max_cells * factor)
        project.terrain.satellite_zoom = satellite_zoom
        project.timeline.travel = float(duration_seconds)
        project.timeline.start_hold = 3.0
        project.timeline.arrival_hold = 5.0
        project.timeline.profile_animation = 6.0
        project.timeline.profile_hold = 4.0
        project.video.fps = fps
        width, height = resolution.split("x", 1)
        project.video.width = int(width)
        project.video.height = int(height)
        project.camera.mode = {
            "Drone": "flyover",
            "Tour de France": "director",
            "Hélicoptère": "director",
            "Cinéma": "director",
            "Director": "director",
        }.get(style, "director")
        return project
