from __future__ import annotations

import math
import statistics
import xml.etree.ElementTree as ET
from pathlib import Path


EARTH_RADIUS_M = 6_371_008.8


def _distance_m(a, b):
    lat1, lon1, _ = a
    lat2, lon2, _ = b
    lat1 = math.radians(lat1)
    lat2 = math.radians(lat2)
    dlat = lat2 - lat1
    dlon = math.radians(lon2 - lon1)
    value = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    )
    return 2 * EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(value)))


def _read_points(gpx_file):
    root = ET.parse(gpx_file).getroot()
    points = []

    for element in root.iter():
        if not (element.tag.endswith("trkpt") or element.tag.endswith("rtept")):
            continue

        elevation = None
        for child in element:
            if child.tag.endswith("ele") and child.text:
                try:
                    elevation = float(child.text)
                except ValueError:
                    pass
                break

        points.append(
            (
                float(element.attrib["lat"]),
                float(element.attrib["lon"]),
                elevation,
            )
        )

    if len(points) < 2:
        raise ValueError("Le GPX doit contenir au moins deux points.")

    return points


def _local_xy(points):
    mean_lat = statistics.fmean(point[0] for point in points)
    mean_lon = statistics.fmean(point[1] for point in points)
    cos_lat = math.cos(math.radians(mean_lat))

    return [
        (
            math.radians(lon - mean_lon) * EARTH_RADIUS_M * cos_lat,
            math.radians(lat - mean_lat) * EARTH_RADIUS_M,
        )
        for lat, lon, _ in points
    ]


def _convex_hull(points):
    points = sorted(set(points))
    if len(points) <= 1:
        return points

    def cross(o, a, b):
        return (
            (a[0] - o[0]) * (b[1] - o[1])
            - (a[1] - o[1]) * (b[0] - o[0])
        )

    lower = []
    for point in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= 0:
            lower.pop()
        lower.append(point)

    upper = []
    for point in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= 0:
            upper.pop()
        upper.append(point)

    return lower[:-1] + upper[:-1]


def _polygon_area(points):
    if len(points) < 3:
        return 0.0

    return abs(
        sum(
            points[index][0] * points[(index + 1) % len(points)][1]
            - points[(index + 1) % len(points)][0] * points[index][1]
            for index in range(len(points))
        )
    ) / 2.0


def _median_smooth(values, window=5):
    radius = window // 2
    return [
        float(
            statistics.median(
                values[max(0, i - radius): min(len(values), i + radius + 1)]
            )
        )
        for i in range(len(values))
    ]


def analyze_gpx(gpx_file):
    gpx_file = Path(gpx_file)
    points = _read_points(gpx_file)

    segments = [
        _distance_m(points[index - 1], points[index])
        for index in range(1, len(points))
    ]

    total_distance = sum(segments)
    start_end = _distance_m(points[0], points[-1])

    xy = _local_xy(points)
    xs = [point[0] for point in xy]
    ys = [point[1] for point in xy]
    width = max(xs) - min(xs)
    height = max(ys) - min(ys)
    hull_area = _polygon_area(_convex_hull(xy))

    mean_spacing = statistics.fmean(segments)
    geometry_confidence = min(
        1.0,
        max(0.4, 30.0 / max(30.0, mean_spacing))
        * max(0.6, min(1.0, len(points) / 500.0)),
    )

    elevations = [point[2] for point in points]
    relief_available = all(value is not None for value in elevations)

    result = {
        "source_file": str(gpx_file),
        "point_count": len(points),
        "distance_total_km": total_distance / 1000.0,
        "distance_start_end_km": start_end / 1000.0,
        "start_end_ratio": start_end / max(total_distance, 1.0),
        "footprint_width_km": width / 1000.0,
        "footprint_height_km": height / 1000.0,
        "footprint_bbox_area_km2": width * height / 1_000_000.0,
        "footprint_hull_area_km2": hull_area / 1_000_000.0,
        "spacing_mean_m": mean_spacing,
        "spacing_median_m": statistics.median(segments),
        "spacing_min_m": min(segments),
        "spacing_max_m": max(segments),
        "point_density_per_km": len(points) / max(total_distance / 1000.0, 0.001),
        "center_latitude": statistics.fmean(point[0] for point in points),
        "center_longitude": statistics.fmean(point[1] for point in points),
        "geometry_confidence_percent": geometry_confidence * 100.0,
        "elevation_completeness_percent": (
            sum(value is not None for value in elevations) / len(elevations) * 100.0
        ),
    }

    if relief_available:
        smoothed = _median_smooth([float(value) for value in elevations])
        gain = 0.0
        loss = 0.0
        grades = []

        for index, distance in enumerate(segments, start=1):
            difference = smoothed[index] - smoothed[index - 1]
            gain += max(0.0, difference)
            loss += max(0.0, -difference)

            if distance >= 2.0:
                grades.append(abs(difference / distance) * 100.0)

        result.update(
            {
                "altitude_min_m": min(smoothed),
                "altitude_max_m": max(smoothed),
                "altitude_amplitude_m": max(smoothed) - min(smoothed),
                "elevation_gain_m": gain,
                "elevation_loss_m": loss,
                "grade_mean_percent": statistics.fmean(grades) if grades else 0.0,
                "grade_median_percent": statistics.median(grades) if grades else 0.0,
                "grade_max_percent": max(grades) if grades else 0.0,
                "relief_confidence_percent": geometry_confidence * 100.0,
            }
        )
    else:
        result.update(
            {
                "altitude_min_m": None,
                "altitude_max_m": None,
                "altitude_amplitude_m": None,
                "elevation_gain_m": None,
                "elevation_loss_m": None,
                "grade_mean_percent": None,
                "grade_median_percent": None,
                "grade_max_percent": None,
                "relief_confidence_percent": 0.0,
            }
        )

    return result
